Copy title extension for QupZilla
-------------------------------------------------
An extension, that will copy the window title into the clipboard.

![context](http://i.imgur.com/3ewZIZU.png)

You will find more information about the configuration and usage of this extension in the [wiki](https://github.com/QupZilla/qupzilla-plugins/wiki/Copy-Title).
