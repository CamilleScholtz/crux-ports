<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi_FI" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Kopio sivun otsikko</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Kopioi kuvan nimi</translation>
    </message>
</context>
</TS>