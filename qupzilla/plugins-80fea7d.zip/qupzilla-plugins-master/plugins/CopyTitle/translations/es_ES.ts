<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_ES" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Copiar título de página</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Copiar nombre de imagen</translation>
    </message>
</context>
</TS>