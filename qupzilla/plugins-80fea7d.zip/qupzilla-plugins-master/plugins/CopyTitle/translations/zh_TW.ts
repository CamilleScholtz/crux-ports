<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>複製頁面標題</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>複製影像名稱</translation>
    </message>
</context>
</TS>