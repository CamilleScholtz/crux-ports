<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru_RU" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Копировать заголовок страницы</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Копировать имя изображения</translation>
    </message>
</context>
</TS>