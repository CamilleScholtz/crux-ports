<?xml version="1.0" ?><!DOCTYPE TS><TS language="el_GR" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Αντιγραφή τίτλου σελίδας</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Αντιγραφή ονομασίας εικόνας</translation>
    </message>
</context>
</TS>