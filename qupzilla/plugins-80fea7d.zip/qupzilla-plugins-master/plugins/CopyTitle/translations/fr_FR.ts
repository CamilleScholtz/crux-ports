<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr_FR" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Copier le titre de la page</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Copier le nom de l&apos;image</translation>
    </message>
</context>
</TS>