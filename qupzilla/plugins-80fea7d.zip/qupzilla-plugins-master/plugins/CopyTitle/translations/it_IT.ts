<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Copia il titolo della pagina</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Copia il nome dell&apos;immagine</translation>
    </message>
</context>
</TS>