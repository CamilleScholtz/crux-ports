<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>复制页面标题</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>复制图像名称</translation>
    </message>
</context>
</TS>