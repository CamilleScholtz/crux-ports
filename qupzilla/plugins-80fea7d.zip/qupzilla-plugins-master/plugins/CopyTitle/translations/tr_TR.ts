<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr_TR" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Sayfa Başlığını Kopyala</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Resim Dosyası Adını Kopyala</translation>
    </message>
</context>
</TS>