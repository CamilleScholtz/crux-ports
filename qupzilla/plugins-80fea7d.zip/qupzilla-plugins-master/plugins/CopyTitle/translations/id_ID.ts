<?xml version="1.0" ?><!DOCTYPE TS><TS language="id_ID" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Salin Judul Halaman</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Salin Nama Gambar</translation>
    </message>
</context>
</TS>