<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr@Ijekavian" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Копирај наслов странице</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Копирај име слике</translation>
    </message>
</context>
</TS>