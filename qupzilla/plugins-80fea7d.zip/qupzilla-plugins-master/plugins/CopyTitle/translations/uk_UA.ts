<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk_UA" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Копіювати заголовок сорінки</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Копіювати назву зображення</translation>
    </message>
</context>
</TS>