<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca_ES" version="2.0">
<context>
    <name>MailHandle_Settings</name>
    <message>
        <source>MailHandle Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:x-large; font-weight:600;&quot;&gt;Mailto links handler&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Web service to use:</source>
        <translation>Servei web a utilitzar:</translation>
    </message>
    <message>
        <source>Gmail</source>
        <translation>Gmail</translation>
    </message>
    <message>
        <source>Mail.ru</source>
        <translation>Mail.ru</translation>
    </message>
    <message utf8="true">
        <source>Яandex</source>
        <translation>Яandex</translation>
    </message>
    <message>
        <source>Outlook</source>
        <translation>Outlook</translation>
    </message>
    <message>
        <source>Yahoo!</source>
        <translation>Yahoo!</translation>
    </message>
    <message>
        <source>My Opera</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>FastMail</source>
        <translation>FastMail</translation>
    </message>
    <message>
        <source>T-Online</source>
        <translation>T-Online</translation>
    </message>
    <message>
        <source>RoundCube</source>
        <translation>RoundCube</translation>
    </message>
    <message>
        <source>Enter URL of your webmail service provider. For example:
https://somewebsite/roundcube</source>
        <translation>Introduïu l&apos;URL del vostre proveïdor del servei web de correu. Per exemple:
https://somewebsite/roundcube</translation>
    </message>
    <message>
        <source>URL of the webmail service provider:</source>
        <translation>URL del proveïdor del servei web de correu:</translation>
    </message>
</context>
</TS>