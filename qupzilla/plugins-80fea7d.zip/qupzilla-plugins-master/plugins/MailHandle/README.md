MailHandle extension for QupZilla
-------------------------------------------------
This extension allows you to handle mailto links on web-pages. 

![conf2](http://i.imgur.com/HKj1DY9.png)

You will find more information about the configuration and usage of this extension in the [wiki](https://github.com/QupZilla/qupzilla-plugins/wiki/Mail-Handle).