Breathe theme for QupZilla
==========================

The Breathe theme strictly uses the Oxygen icon set. It is mostly based on Default Linux theme by David Rosca. This theme is included in the QupZilla tarball.

Screenshot:
![breathe](http://i.imgur.com/2Q6jSPz.png)